# Joyal Xavier A — Personal Portfolio

A three-page personal portfolio built with Next.js (App Router), TypeScript, Tailwind CSS, and Framer Motion, plus a database-backed progress calendar for the PM-VIKAS IoT training program at IIIT Kottayam.

## Pages

| Route | Contents |
|---|---|
| `/` (Home) | Hero with contact info, Projects, compact Contact section |
| `/about` | About, Skills, Experience, Education, Certifications, Achievements |
| `/pm-vikas` | PM-VIKAS program overview + the daily progress calendar |

Navigation, the theme toggle, and the admin login live in the navbar on every page (`components/Navbar.tsx`), rendered once from `app/layout.tsx`.

## What's on the PM-VIKAS page

- **Program overview** — real, researched details about PM-VIKAS (a Ministry of Minority Affairs scheme) and IIIT Kottayam's role as the first higher-education institute selected to implement it, plus how the IoT training track fits in.
- **Progress calendar** — a month-by-month calendar. Anyone visiting the site can view logged entries (read-only). Only whoever logs in with the admin password can add, edit, or delete a day's entry.
- Entries are stored in a real **Postgres database**, not the browser — so they show up the same way for every visitor, and survive across devices/browsers.

## Admin login

- Click **Login** in the top-right of the navbar, enter the password, and submit.
- On success, the navbar shows **Admin active**, and the calendar's textarea/save/delete controls become usable.
- The password is checked server-side (`app/api/auth/route.ts` and inside `app/api/progress/route.ts`) against `process.env.ADMIN_PASSWORD`, with a fallback default of `pmvikas2026` defined in `lib/auth.ts` if you don't set one.
- **Set a real password before sharing your live link:** add `ADMIN_PASSWORD` in Vercel's Environment Variables (Project → Settings → Environment Variables). This is intentionally a single shared password — no user accounts — matching a personal site's needs rather than a multi-user system.

## Database setup (Neon or Supabase via Vercel)

Vercel no longer offers its own Postgres product directly — it connects you to **Neon** or **Supabase** instead, both of which have a free tier. Either works identically here since the code just uses a standard `DATABASE_URL` connection string.

1. Push this project to a GitHub repository and import it into Vercel (see Deployment section below) — or do this step first, before your first deploy.
2. In your Vercel project, go to the **Storage** tab → **Create Database** → choose **Neon** or **Supabase** (whichever is offered/preferred) → follow the prompts.
3. Once created and connected to this project, Vercel automatically adds a `DATABASE_URL` environment variable — you don't need to copy/paste anything for production.
4. **For local development**, copy the same connection string into a `.env.local` file (see `.env.example`):
   ```
   DATABASE_URL=postgres://...
   ADMIN_PASSWORD=your-own-password
   ```
5. No manual table creation needed — the app runs `CREATE TABLE IF NOT EXISTS` automatically the first time it queries the database (see `lib/db.ts`).

**Table schema** (created automatically):
```sql
CREATE TABLE IF NOT EXISTS pm_vikas_progress (
  date_key TEXT PRIMARY KEY,      -- e.g. '2026-07-17'
  entry_text TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## Project structure

```
portfolio/
├── app/
│   ├── layout.tsx            # Navbar, Footer, theme + admin-auth providers, SEO metadata
│   ├── page.tsx                # Home: Hero, Projects, Contact
│   ├── about/page.tsx           # About, Skills, Experience, Education, Certifications, Achievements
│   ├── pm-vikas/page.tsx         # Program overview + progress calendar
│   ├── api/
│   │   ├── auth/route.ts          # POST: verify admin password
│   │   └── progress/route.ts       # GET (public), POST/DELETE (admin-only) — talks to Postgres
│   └── globals.css
├── components/
│   ├── Navbar.tsx              # Multi-page nav, active-route highlight, login widget, theme toggle
│   ├── LoginWidget.tsx           # Password popover + "Admin active" badge
│   ├── AdminAuthProvider.tsx      # React context: isAdmin, password, login(), logout()
│   ├── Hero.tsx, Projects.tsx, Contact.tsx           # Home page sections
│   ├── About.tsx, Skills.tsx, Experience.tsx,
│   │   Education.tsx, Certifications.tsx, Achievements.tsx   # About page sections
│   ├── PmVikasInfo.tsx            # PM-VIKAS program overview content
│   ├── PmVikasCalendar.tsx         # The calendar itself — fetches/saves via /api/progress
│   ├── Section.tsx, Reveal.tsx      # Shared layout/animation helpers
│   ├── ThemeProvider.tsx, ThemeToggle.tsx
│   └── Footer.tsx, ScrollProgress.tsx, ScrollToTop.tsx
├── lib/
│   ├── data.ts                # All resume content — edit this to update your details
│   ├── db.ts                   # Postgres connection + queries
│   ├── auth.ts                  # Password check shared by both API routes
│   └── utils.ts
├── public/                      # Add resume.pdf, profile.jpg, favicon here
├── .env.example
├── next.config.js
└── package.json
```

All resume content is centralized in **`lib/data.ts`** — edit that file to update your details across every page.

## Setup instructions

1. **Install dependencies**
   ```bash
   npm install
   ```

2. **Add your assets** to `public/`: `resume.pdf` (Download Resume button) and `profile.jpg` (already included).

3. **Set up the database** — see the Database setup section above. At minimum, create `.env.local` with `DATABASE_URL` and `ADMIN_PASSWORD` for local testing.

4. **Fill in placeholders** in `lib/data.ts`: your GitHub URL, and project `github`/`demo` links once available.

5. **Run locally**
   ```bash
   npm run dev
   ```
   Visit `http://localhost:3000`.

## Deploying to Vercel

This project needs live API routes and a database, so it's built for **Vercel** (not a static host like GitHub Pages).

1. Push the project to a GitHub repository.
2. Go to vercel.com/new, sign in with GitHub, and import the repo. Vercel auto-detects Next.js — no config needed.
3. **Before or right after the first deploy**, connect a database from the **Storage** tab (see Database setup above) — Vercel wires up `DATABASE_URL` for you.
4. Add `ADMIN_PASSWORD` under **Settings → Environment Variables** with your own password, then redeploy (Vercel → Deployments → ⋯ → Redeploy) so the new variable takes effect.
5. Once deployed, update the `siteUrl` constant in `app/layout.tsx` to your real `*.vercel.app` URL (or custom domain), commit, and push — Vercel redeploys automatically and your link previews will be correct.

## Suggested future improvements

- Swap the single shared admin password for a proper auth provider (e.g. NextAuth) if you ever want multiple editors or stronger security.
- Add pagination to the "Recent entries" list once the calendar has months of history.
- Add a small analytics widget on the PM-VIKAS page (e.g. total days trained vs. program duration) once you know the program's end date.
- Add real GitHub/live-demo links to each project card as they become available.
