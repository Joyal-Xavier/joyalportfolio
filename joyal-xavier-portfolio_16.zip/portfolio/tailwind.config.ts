import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Circuit-board inspired palette
        graphite: {
          950: "#0A0E14", // deep pcb substrate
          900: "#0F151D",
          800: "#141C27",
          700: "#1B2531",
          600: "#26313F",
        },
        paper: {
          50: "#F7F9FB",
          100: "#EEF2F6",
          200: "#E2E8EE",
        },
        signal: {
          // trace / accent blue
          500: "#3B82F6",
          400: "#5B9BFA",
          300: "#8AB8FC",
        },
        copper: {
          // secondary warm accent, used sparingly (solder-pad copper)
          400: "#5EEAD4",
          500: "#2DD4BF",
        },
        ink: {
          900: "#0B0F14",
          700: "#33404D",
          500: "#5C6B79",
          300: "#94A3B3",
        },
      },
      fontFamily: {
        mono: ["var(--font-jetbrains)", "JetBrains Mono", "monospace"],
        sans: ["var(--font-inter)", "Inter", "sans-serif"],
      },
      backgroundImage: {
        "grid-dark":
          "linear-gradient(to right, rgba(94,234,212,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(94,234,212,0.06) 1px, transparent 1px)",
        "grid-light":
          "linear-gradient(to right, rgba(59,130,246,0.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(59,130,246,0.06) 1px, transparent 1px)",
      },
      backgroundSize: {
        grid: "32px 32px",
      },
      keyframes: {
        "trace-draw": {
          "0%": { strokeDashoffset: "1000" },
          "100%": { strokeDashoffset: "0" },
        },
        "pulse-node": {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: "0.6", transform: "scale(1.25)" },
        },
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "scan-line": {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(100%)" },
        },
      },
      animation: {
        "trace-draw": "trace-draw 2.4s ease-out forwards",
        "pulse-node": "pulse-node 2.6s ease-in-out infinite",
        "fade-up": "fade-up 0.6s ease-out forwards",
      },
    },
  },
  plugins: [],
};

export default config;
