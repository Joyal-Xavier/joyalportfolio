"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowDown, Download, Mail } from "lucide-react";
import { profile } from "@/lib/data";

const NODES = [
  { x: 60, y: 40, label: "ESP32" },
  { x: 260, y: 20, label: "Arduino" },
  { x: 460, y: 60, label: "OpenCV" },
  { x: 640, y: 30, label: "MATLAB" },
];

const TYPE_PHRASES = [
  "IoT · Embedded Systems · Digital Image Processing",
  "ESP32 · Arduino · Sensor Interfacing",
  "Breadboard to prototype, one signal at a time",
];

function Typewriter() {
  const [text, setText] = useState("");

  useEffect(() => {
    let phraseIdx = 0;
    let charIdx = 0;
    let deleting = false;
    let timeoutId: ReturnType<typeof setTimeout>;

    const tick = () => {
      const phrase = TYPE_PHRASES[phraseIdx];
      if (!deleting) {
        charIdx++;
        setText(phrase.slice(0, charIdx));
        if (charIdx === phrase.length) {
          deleting = true;
          timeoutId = setTimeout(tick, 1400);
          return;
        }
        timeoutId = setTimeout(tick, 45);
      } else {
        charIdx--;
        setText(phrase.slice(0, charIdx));
        if (charIdx === 0) {
          deleting = false;
          phraseIdx = (phraseIdx + 1) % TYPE_PHRASES.length;
          timeoutId = setTimeout(tick, 300);
          return;
        }
        timeoutId = setTimeout(tick, 25);
      }
    };

    timeoutId = setTimeout(tick, 300);
    return () => clearTimeout(timeoutId);
  }, []);

  return (
    <>
      {text}
      <span className="type-caret">▍</span>
    </>
  );
}

export function Hero() {
  const scrollTo = (id: string) =>
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });

  return (
    <section
      id="home"
      className="relative flex min-h-[100svh] flex-col justify-center overflow-hidden bg-circuit px-6 pt-24 pb-16"
    >
      {/* subtle scanning glow, reinforcing the circuit-board motif */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-2/5 bg-gradient-to-b from-copper-400/[0.06] to-transparent animate-[scan-line_6s_linear_infinite]"
        aria-hidden="true"
      />

      {/* signature circuit trace, connecting the technologies behind the work */}
      <svg
        viewBox="0 0 700 100"
        className="pointer-events-none absolute left-1/2 top-[64%] w-[92%] max-w-4xl -translate-x-1/2 opacity-60 sm:top-[68%]"
        aria-hidden="true"
        preserveAspectRatio="xMidYMid meet"
      >
        <path
          d="M 60 40 C 140 40, 180 20, 260 20 S 380 60, 460 60 S 580 30, 640 30"
          fill="none"
          stroke="currentColor"
          className="text-signal-500 dark:text-signal-400"
          strokeWidth="1.5"
          strokeDasharray="1000"
          style={{ animation: "trace-draw 2.4s ease-out forwards" }}
        />
        {/* flowing "current" riding along the trace */}
        <path
          d="M 60 40 C 140 40, 180 20, 260 20 S 380 60, 460 60 S 580 30, 640 30"
          fill="none"
          stroke="currentColor"
          className="signal-dash text-copper-400"
          strokeWidth="1.2"
          opacity="0.8"
        />
        {NODES.map((n, i) => (
          <g key={n.label}>
            <circle
              cx={n.x}
              cy={n.y}
              r="4"
              className="fill-copper-500 dark:fill-copper-400"
              style={{
                animation: "pulse-node 2.6s ease-in-out infinite",
                animationDelay: `${i * 0.3}s`,
              }}
            />
            <text
              x={n.x}
              y={n.y - 12}
              textAnchor="middle"
              className="fill-ink-500 dark:fill-ink-300"
              fontSize="10"
              fontFamily="var(--font-jetbrains)"
            >
              {n.label}
            </text>
          </g>
        ))}
      </svg>

      <div className="relative mx-auto w-full max-w-4xl text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto mb-6 h-32 w-32 sm:h-36 sm:w-36"
        >
          <span
            className="absolute inset-0 rounded-full bg-gradient-to-tr from-signal-500 via-copper-400 to-signal-400 opacity-70 blur-[2px]"
            aria-hidden="true"
          />
          <span className="absolute inset-[3px] rounded-full bg-paper-50 dark:bg-graphite-950" />
          <Image
            src="/profile.jpg"
            alt={`Portrait of ${profile.name}`}
            fill
            priority
            sizes="144px"
            className="relative rounded-full object-cover p-1.5"
          />
          <span
            className="absolute -bottom-1 -right-1 h-3.5 w-3.5 rounded-full bg-copper-400 ring-4 ring-paper-50 dark:ring-graphite-950 animate-pulse-node"
            aria-hidden="true"
          />
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="eyebrow mb-5"
        >
          <Typewriter />
        </motion.p>

        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-6xl font-semibold tracking-tight text-ink-900 dark:text-paper-50"
        >
          {profile.name}
        </motion.h1>

        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-4 text-lg sm:text-xl font-medium text-signal-500 dark:text-signal-400"
        >
          {profile.title}
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mx-auto mt-6 max-w-2xl text-base sm:text-lg text-ink-500 dark:text-ink-300"
        >
          {profile.summary}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
        >
          <a
            href={profile.resumeFile}
            download
            className="inline-flex items-center gap-2 rounded-md bg-signal-500 px-5 py-2.5 text-sm font-medium text-white transition-colors hover:bg-signal-400"
          >
            <Download size={16} />
            Download Resume
          </a>
          <button
            onClick={() => scrollTo("contact")}
            className="inline-flex items-center gap-2 rounded-md border border-ink-300/40 dark:border-ink-500/40 px-5 py-2.5 text-sm font-medium text-ink-900 dark:text-paper-50 transition-colors hover:border-copper-400 hover:text-copper-500 dark:hover:text-copper-400"
          >
            <Mail size={16} />
            Contact Me
          </button>
          <button
            onClick={() => scrollTo("projects")}
            className="inline-flex items-center gap-2 rounded-md px-5 py-2.5 text-sm font-medium text-ink-700 dark:text-paper-100/90 transition-colors hover:text-signal-500 dark:hover:text-signal-400"
          >
            View Projects
            <ArrowDown size={14} />
          </button>
        </motion.div>
      </div>

      <button
        onClick={() => scrollTo("projects")}
        aria-label="Scroll to Projects section"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-ink-500 dark:text-ink-300 animate-bounce"
      >
        <ArrowDown size={20} />
      </button>
    </section>
  );
}
